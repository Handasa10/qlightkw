# Production: 3D + motion graphics (and the other styles built from 3D renders)

`T` = this skill's `toolkit/` folder. `W` = a fresh scratch folder for this video. Tools needed: node + Playwright
Chromium, ffmpeg, python3 with numpy and Pillow (all present in Claude Code cloud sessions).

## Style rule (the owner's choice, 2026-11-03): like the first videos
The owner wants every reel to look like the first 3D reels (stairs, colours, accent spot), not like a still background
under a dark layer with 2D drawings on top:
- **A 3D scene built for this topic.** Never reuse a room or render from a reel that was already published; if a body
  fits, give it a new layout, views and states for this topic, or write a new body.
- **The light changes inside the 3D scene**: render sequences (`grow:0.15…1`, `age:0.15…1`, step 1…14) and crossfade
  them, so the viewer sees the room light up, age, get fixed. Many renders per reel (25–40), at least one per idea.
- **The render stays bright and visible**: only the top/bottom `shade2` gradients; a full-frame dim is allowed only
  behind the logo/offer and CTA scenes (≤ .55). No 2D diagram as the main picture: build the close-up in 3D (a
  detail station far from the room, like `strip_bed`'s `PX` cove piece) and keep 2D to small labels and chips.
- Text: one title at the top, one chip at the bottom (`title2`, `sub2`, `pop`), timed to the voice.

## 0. Once per session
`cd $T/3d && npm install --silent` (three.js 0.170 for the 3D rooms).

## 1. Work folder
`bash $T/reel/new.sh $W` copies the template: engine, base helpers, fonts, logos, `render.js`, `build.sh`,
`runvid.sh`, `synth.py`, `align.py`, `cut.py`. Copy the voice to `$W/vo.wav` and make the analysis copy:
`ffmpeg -i $W/vo.wav -ac 1 -ar 48000 -c:a pcm_s16le $W/vo48.wav`. Duration: `ffprobe -v error -show_entries
format=duration -of csv=p=0 $W/vo.wav`. Reel length = voice + 0.3 s.

## 2. Timing (the video follows the voice)
Put the spoken lines (no tags) in `lines=[...]` in `$W/align.py`, then `python3 align.py <n> x` in `$W`. It prints the
speech segments (start, end, length, syllable peaks) and a suggested line mapping. **Check the mapping by hand**:
short segments are often one word («لا…», «وفجأة…», «نصيحتي»); if a line's peak count doesn't fit, shift it. Write
down the start time of every phrase; every on-screen event is keyed to these times. Plan scenes so a scene changes
with each idea (typically 10–12 scenes for 60–80 s).

## 3. 3D renders
Rooms in `$T/3d/bodies/`: `living_colors` (sofa, leather chair, walnut table; states show/cold/warm/yellow/mixed),
`accent_corner` (painting + console; mode dark/flat/spot, beam, pos good|bad, cct, cri, dim), `garden` (day/dusk/
night + path/tree/wall/seat layers), `wardrobe` (doors, shelf/rail/drawer LEDs), `stairs`, `majlis`, `cove_hall` (gypsum cove, voltage drop 12v/24v; `new` white strip vs `aged` cheap strip a year later: yellow, dim, dead patches), `cafe` (flat panels vs pendants + bar spots + shelf LEDs; layer tokens `panels pend bar shelf wash`), `shop` (boutique wall: flat downlights vs track spots + under-shelf linear; tokens `flat track shelf`), `mirror` (vanity: downlight over the head vs side LED bars; tokens `top side bust`; draw faces as 2D diagrams, a sculpted 3D face reads uncanny), `gypsum` (ceiling before closing: grid, drivers + hatches, cables, cove channel, marked spots; presets `open closed hatch test done`), `strip_bed` (master bedroom with a gypsum cove: `new`, `aged`, `age:<0..1>`, `grow:<0..1>`; detail station views `d`/`e`: `flat`, `burn:<0..1>`, `sag`, `prof`, `cover`), `roof` (winter roof terrace at night: tokens `night|dusk + str:<0..1> + wall + path:<0..1>`; detail views `d`/`e` with `ip+rain`), `curtain` (living room curtain wall with a gypsum pelmet: `off|room + wash:<0..1> + dim:<x>`; detail view `d@det` = the pelmet cut open), `stonewall` (courtyard wall built from real 3D stones: `top` flat flood vs `graze:<0..1>` in-ground up-lights; views `w a m`), `kidsroom` (kids' bedroom at night: `off`, `cold` harsh white ceiling light, `night:<0..1>` warm floor-level night lights, `read:<0..1>` dimmable story light; views `w b f`; no faces), `reception` (company lobby: slat logo wall, counter, desk; `panels` flat cold grid vs `logo` spots, `counter` hidden strip, `linear` pendant, `downs`; `design` = all four; views `w c l`), `entrance` (villa entrance at night: stone-clad door frame, `sconce:<0..1>` up/down wall lights, `steps:<0..1>` brick lights in the cheek walls, `num` halo-lit house number, `rain` for IP65; `all` = sconce+steps+num; views `w s n e`), `gym` (home gym: `bulb` one yellow bulb vs `linear:<0..1>` recessed 4000 K anti-glare rows + `mirror` side bars; `all` = linear+mirror; mirror reflects via a cube camera; faceless figure; views `w b m`), `apartment` (rented flat living room: `ceil` one cold ceiling lamp vs `sconce` plug-in wall light with its cord to the socket, `floor` lamp, `table` lamp; `cozy` = all three; `tint:<0..1>` smart-bulb hue; views `w s f`), `warehouse` (tall pallet-rack warehouse: `old` weak yellow lamps vs `hb:<0..1>` LED high-bays row by row, `dust` for IP65; views `w u r d`), `barber` (barber shop: `spot` one spot over the head vs `mirror` 4000 K side bars + `linear` ceiling; `all` = mirror+linear; faceless client; mirror via cube camera; views `w c s`), `perfume` (perfume shop: `panel` flat ceiling panel vs `shelves:<0..1>` strips under glass shelves + backlit panel and `hero` 12–15° spot on the star bottle; `all` = shelves+hero; views `w s h`), `floatbed` (floating bed: `ceil` one ceiling lamp vs `glow:<0..1>` warm strip under a recessed plinth, `path` motion-sensor lights to the door; views `w f n`), `coffee` (home coffee corner: `ceil` far ceiling light vs `strip:<0..1>` hidden strip under the shelf + `pend` small warm pendant; `all` = strip+pend; views `w c s`), `camp` (winter desert camp at night: `flood` one harsh white floodlight on a pole vs `warm:<0..1>` 2700 K string lights + lanterns over the majlis, `path` small aimed floodlight to the cars, `ip` the pole head re-lit warm, `dust` for IP65; `all` = warm+path; views `w s p d`), `lobby` (apartment-building lobby: `panels` flat cold ceiling panels vs `cove:<0..1>` hidden 3000 K strip in a gypsum ceiling cove, `sconce` up/down sconces by the lift and the entrance, `downs` glare-free downlights over the mailboxes and the desk; `all` = cove+sconce+downs; views `w m e u`), `magtrack` (product hero, magnetic track over a dining table: `n:<0..3>` spot heads on the track, `on`, `slide:<0..1>` head 2 slides into place, `lift:<0..1>` head 3 below the track then clicked on, `linear`, `pend`, `room` fill; views `c` close up at the track, `w` room, `s` macro), `newhome` (5 common mistakes in one flat: `mix` spots alternating 2700/6500 K vs `plan` 6 spots 3000 K, `sieve` 20 spots, `vtop` downlight over the head at the vanity vs `vside` mirror side bars, `bare` yellowed strip without profile vs `strip` in a profile, `dim:<0..1>` dimmer; spots quiz: `crowd` 16 cold spots in a tight 4×4 grid vs `even` 8 warm spots in two rows of four (only the active set's rings show); views `w c b p`, `q` room with the ceiling, `k` looking up at the whole ceiling), `master` (master bedroom for a satisfying layer-by-layer switch-on: `off`, `cove:<0..1>` hidden strip in a ceiling cove, `sconce` bedside wall sconces, `spots` grazing the tufted headboard; `all`; views `w b`), `restaurant` (dining room: `panels` flat cold panels with dull low-CRI food vs `spots:<0..1>` narrow 2700 K spot per table, `cri` vivid food colours, `wash` slat-wall wash; `all` = spots+cri+wash; views `w t d`), `bagshoe` (bags & shoes boutique: `panels` flat cold panels with dull matte leather vs `spots:<0..1>` narrow CRI 95 spots per piece, `cri` true leather colour + sheen, `shelf:<0..1>` hidden strips under the shoe shelves then the bag cubbies; `all` = spots+cri+shelf; views `w b s t`), `spotlin` (spot or linear? open-plan flat: `off` base light, `spots:<0..1>` painting / sofa / plant corner / corridor console, `linear:<0..1>` suspended linear over the dining table, recessed line down the corridor, under-cabinet line over the counter; `all`; views `w p d c`), `phoneshop` (phone shop: `panels` cold panels with glare on every screen vs `case:<0..1>` hidden strips inside the glass vitrines then the wall shelves, `spots` 4000 K over the demo table; `all` = case+spots; views `w v t s`), `salon` (villa living room for a satisfying layer-by-layer switch-on: `off`, `cove:<0..1>` hidden strip in a gypsum drop band, `spots` on the painting / coffee table / console, `sconce` brass wall sconces on the fluted panel, `chand:<0..1>` crystal chandelier; `all`; views `w c s` — `s` is a tight painting close-up), `gypsite` (villa family hall on site before the gypsum is closed: `site` raw room with open tiles, `ghost:<0..1>` planned furniture as blue holograms, `marks:<0..1>` red X spot positions + aim beams to the TV wall / painting / table, `channel:<0..1>` cove lip + profile highlighted orange, `cut` hides the left wall for the section view `c`, `dimmer:<0..1>` back box + conduit highlighted; `done` finished room, `lights:<0..1>`, `dim:<0..1>`; views `w u c d`), `kitchen` (villa kitchen for a satisfying layer-by-layer switch-on: `off`, `under:<0..1>` strip under the wall cabinets piece by piece, `spots` recessed ceiling spots, `pend:<0..1>` three dome pendants over the marble island one after another, `shelf` strips under the open oak shelves; `all`; views `w c s`), `villacut` (two-storey villa cut open at the front, at night, for contractor / whole-project topics: 6 rooms + garden; `off`, `in:<0..1>` 3000 K spots room by room, `hid:<0..1>` cove strips room by room, `out:<0..1>` wall washers, palm up-lights, boundary-wall lights and path bollards; `mix` = `ms+mh+mo` the same villa bought from several shops (each room a different colour temperature, a cold cove and a yellow one, greenish garden floods), `flick:<0..1>` cheap drivers dip two rooms; `drv` matching drivers in the void above the gypsum with green LEDs vs `cheap` odd ones with red LEDs; `all` = in+hid+out; views `w a g u e d` — `d` is the driver close-up), `villaproj` (one villa ground floor from site to lit, for project-of-the-week: `site` raw concrete + block, `plan` blueprint on the floor with spot / cove / sconce marks, `wire` ceiling studs + orange cables + drivers, `done` finished with furniture, `lit:<0..1>` hall → kitchen → entrance, `top` hides ceilings for the bird's-eye `t`, `dim:<x>`; views `t c h k e`), `diwan` (Kuwaiti diwaniya for a satisfying switch-on: long room toward a carved double door, Sadu floor seating along both walls, brass tray + dallah; `off`, `cove:<0..1>` hidden strip around a raised gypsum centre, `spots:<0..1>` wall grazers over the seating front to back, `chand:<0..1>` 3-tier crystal chandelier, `ent` up/down sconces by the door; `all`; views `w c s`), `ledlab` (LED myths lab, three stations: heat `on`, `heat:<0..1>` the cheap spot's back glows, `age:<0..1>` it yellows with dead dots vs a finned heat sink; lumens `lmon`, `lm` one of two "12 W" spots weak; dimmer `dl:<0..1>`, `flick` cheap-driver unevenness; views `h b c f l d`), `facade` (villa front at night from the street: `bad` one cold floodlight on the gate pillar, `wash:<0..1>` in-ground grazers, `palm:<0..1>`, `path:<0..1>` bollards, `win`, `rain`; `all`; views `w g s`, plus `d` close-up which still frames poorly). Note: keep wall-mounted things in front of the wall face (z ≥ -0.02) or they z-fight / vanish inside the wall. Each body
defines `VIEWS` (cameras) and `window.setState(string)`; read the body to learn its states.

Shoot: `node $T/3d/shoot.js <body> "view@state;view@state" 540 960 $W/test` (small test) → contact sheet with PIL
→ fix → `node $T/3d/shoot.js <body> "..." 1080 1920 $W/r` (final). Files are named `<view>_<state>.jpg` with `: | +`
turned into `-`; rename them to short keys (`m_warm.jpg`) for `part.js`.

New room or product: write `$T/3d/bodies/<name>.html` in the same style (it is concatenated between `head.html` and
`tail.html`: use the helpers there: `box`, `plane`, `canvasTex`, `woodDraw`, materials `M.*`, `emis`, `plant`).
Lessons:
- Make the lighting difference obvious at phone size; test the extreme states side by side first.
- Transparent helper meshes still darken the image through the AO pass: hide them (`visible = false`).
- Close-up views blow out easily: lower the light, don't raise exposure.
- Effects that can't be rendered physically (e.g. low CRI) can be simulated on the image with PIL; say so in the review.

## 4. Scenes: `$W/part.js`
Start from the closest example in `$T/reel/examples/` (`accent_spot.js`, `furniture_colors.js`, `garden.js`,
`wardrobe.js`, `stairs.js`) and keep its skeleton: helper functions, `S1..Sn(t)`, the `SCENES` table
`[start, end, fn, …]`, `draw(t)` (start it with `beginFrame()`, end with `endFrame(t)`), `init()` loading `IM[key]`.
Useful helpers: `bgImg keyed flash shade2 title2 sub2 label pop sparkles imgCard glow icon sweep drawImg`, and the
per-example ones (`versus` cards ✗/✓, `gauge`, `spectrum`, `beamGauge`, `angleDiagram`, `tip`, `badge`, before/after
slider). Ending: logo scene with what we do (no design-fee / price card: withdrawn by the owner), then the CTA scene
(pin + حولي + شارع تونس, WhatsApp pill +965 5111 1725, logo, «خلّ بيتك ينوّر صح ✨», @quality_light1). QL logo
bottom-left from ~3 s until the logo scene. No subtitles.

Arabic + Latin in one string can flip order ("15° – 24°", "CRI 90+", "+965…"): use `dir: 'ltr'` on pure-Latin
texts, rephrase mixed ones («مؤشر ألوان 90 وفوق»), and always check the stills.

## 4b. Cover (thumbnail): a real frame of the video, chosen by the owner
The owner's reels that spread widest had a cover he picked himself: the first frame is a real frame of the video that
says what it is about (with its on-screen text), not a designed card. So:
- Don't call `drawCover` in `draw(t)`; the reel starts straight on the hook.
- After the final render, pick the 3 strongest frames (the before/after or reveal moment with its title, the most
  dramatic 3D close-up, the problem shown in the room) and make the numbered sheet:
  `python3 $T/reel/thumbs.py sheet out/<slug>.mp4 t1 t2 t3 thumbs/sheet.jpg`, upload it
  (`studio.py upload … reels/<slug>_covers.jpg`), and queue a card with the picture: insert into `content_questions`
  (`header` «غلاف فيديو …», `question`, 3 `options` with a short label each, `recommended` 0 = your pick,
  `image_url` = the sheet URL), then POST `{"action":"flush"}` to the function. Send it together with media_ready.
- On his answer (the watcher returns it), or with your pick if it is still unanswered when you schedule:
  `python3 $T/reel/thumbs.py apply out/<slug>.mp4 <t> out/<slug>_c.mp4 out/<slug>_cover.jpg` (holds that frame over
  the first 0.6 s), make the Postora copy from `<slug>_c.mp4` and upload it. If the posts were already scheduled with
  the old file, cancel those four and create them again with the new media (same time and captions).

## 5. Check stills
`bash build.sh <duration>` then `node render.js stills "t1,t2,…"` (1–2 per scene, plus every tricky moment) → contact
sheet (PIL, e.g. 10 per row at 216×384) → look → fix overlaps, empty frames, wrong order, unreadable text → repeat.

## 6. Sound
Write `$W/music.json` (example: `$T/reel/examples/furniture_colors.music.json`):
`dur`, `drop` (the reveal: beat starts), `hats` (≈ first content scene), `lift` (≈ offer scene: louder pads + claps),
`end` (= duration − 1.8: final chord), `transitions` (scene starts → whoosh), `events` `[name, time, gain, …args]`
with `pop click chime impact riser whoosh thud coin crack buzz` on the visual beats. `python3 synth.py` → `mix.wav`
(voice + ducked music + SFX).

## 7. Render
`bash runvid.sh <duration> $W/out/<slug>.mp4` in the background (~20–30 min for 60–80 s). It writes the final MP4
(< 50 MB) and `<slug>_preview.mp4`. Then extract 4 frames (`ffmpeg -ss t -i … -frames:v 1`) and look at them.
